# Parallel_Computing-2018
  - How to run:
	mpicc -o testMpi testMpi.c -lm
	mpirun -np 2 testMpi

